let typed = new Typed('#typed', {
    strings: [
        "Web Developer",
        "Tech Enthusiast",
        "Creative Designer"
    ],
    typeSpeed: 50, // Typing speed in milliseconds
    backSpeed: 30, // Deleting speed in milliseconds
    loop: true, // Loop the animation
    showCursor: true, // Show the blinking cursor
    cursorChar: '|', // Custom cursor character
});
// Skills data - replace with your actual skills
const skills = [{
        name: "JavaScript",
        level: 90,
        color: "#F7DF1E"
    },
    // {
    //     name: "React",
    //     level: 85,
    //     color: "#61DAFB"
    // },
    // {
    //     name: "Node.js",
    //     level: 80,
    //     color: "#339933"
    // },
    {
        name: "CSS/SCSS",
        level: 88,
        color: "#1572B6"
    },
    {
        name: "HTML5",
        level: 95,
        color: "#E34F26"
    },
    {
        name: "TypeScript",
        level: 75,
        color: "#3178C6"
    },
    {
        name: "Python",
        level: 80,
        color: "#3776AB"
    },
    {
        name: "Git",
        level: 85,
        color: "#F05032"
    }
];

// DOM elements
const skillsGrid = document.querySelector('.skills-grid');
const skillsTags = document.querySelector('.skills-tags');
const techJourneyCard = document.querySelector('.tech-journey-card');

// Generate skill cards
function generateSkillCards() {
    skills.forEach((skill, index) => {
        // Create skill card
        const skillCard = document.createElement('div');
        skillCard.className = 'skill-card';
        skillCard.style.borderLeft = `4px solid ${skill.color}`;

        // Create skill header (name and level)
        const skillHeader = document.createElement('div');
        skillHeader.className = 'skill-header';

        const skillName = document.createElement('div');
        skillName.className = 'skill-name';
        skillName.textContent = skill.name;

        const skillLevel = document.createElement('div');
        skillLevel.className = 'skill-level';
        skillLevel.textContent = `${skill.level}%`;

        skillHeader.appendChild(skillName);
        skillHeader.appendChild(skillLevel);

        // Create skill bar
        const skillBarContainer = document.createElement('div');
        skillBarContainer.className = 'skill-bar-container';

        const skillBar = document.createElement('div');
        skillBar.className = 'skill-bar';
        skillBar.style.backgroundColor = skill.color;

        skillBarContainer.appendChild(skillBar);

        // Create glow effect
        const skillGlow = document.createElement('div');
        skillGlow.className = 'skill-glow';
        skillGlow.style.background = `radial-gradient(circle at 50% 50%, ${skill.color}, transparent 70%)`;

        // Assemble skill card
        skillCard.appendChild(skillHeader);
        skillCard.appendChild(skillBarContainer);
        skillCard.appendChild(skillGlow);

        // Add event listeners
        skillCard.addEventListener('mouseenter', () => {
            skillBar.style.width = `${skill.level}%`;
        });

        skillCard.addEventListener('mouseleave', () => {
            skillBar.style.width = '0';
        });

        // Add to DOM
        skillsGrid.appendChild(skillCard);

        // Set animation delay for entrance
        setTimeout(() => {
            skillCard.classList.add('animated');
        }, 100 * index);
    });
}

// Generate skill tags
function generateSkillTags() {
    skills.forEach(skill => {
        const skillTag = document.createElement('span');
        skillTag.className = 'skill-tag';
        skillTag.textContent = skill.name;
        skillTag.style.backgroundColor = skill.color;
        skillTag.style.color = '#000';

        skillsTags.appendChild(skillTag);
    });
}

// Initialize animations
function initAnimations() {
    // Animate tech journey card
    setTimeout(() => {
        techJourneyCard.classList.add('animated');
    }, skills.length * 100 + 300);
}

// Initialize everything when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    generateSkillCards();
    generateSkillTags();
    initAnimations();
});

// Add scroll-triggered animations
function handleScroll() {
    const scrollPosition = window.scrollY + window.innerHeight;
    const techJourneyPosition = techJourneyCard.offsetTop;

    if (scrollPosition > techJourneyPosition) {
        techJourneyCard.classList.add('animated');
    }
}

window.addEventListener('scroll', handleScroll);
// Project data - replace with your actual projects
const projects = [{
        title: "CareerMorph",
        description: "CareerMorph empowers job seekers with AI-driven insights, transforming resumes into opportunities and skills into career growth. 🚀📊 Unlock your potential with data-driven career guidance!",
        image: "https://res.cloudinary.com/dgtfoqrjo/image/upload/v1740502046/Screenshot_2025-02-25_121120_qwtgmu.png",
        tags: ["React", "Node.js", "HTML", "CSS", "JS"],
        liveLink: "https://careermorph.lovable.app/",
    },
    {
        title: "IPL Hub",
        description: "Developed a responsive and visually appealing hotel website using HTML, CSS and JS emphasizing clean design and functionality.",
        image: "https://res.cloudinary.com/dgtfoqrjo/image/upload/v1741254229/Screenshot_2025-03-06_151253_lvv23b.png",
        tags: ["CSS", "HTML", "JS"],
        liveLink: "https://ipl.lovable.app/",

    },
    {
        title: "QuickCare",
        description: "Designed and developed a medical services website using loveable focusing on people's health and wellness with modern aesthetics and responsive design.",
        image: "https://res.cloudinary.com/df2sbz9ye/image/upload/v1743832717/Screenshot_2025-04-05_112526_zqz6lh.png",
        tags: ["JavaScript", "HTML", "Tailwind CSS", "loveable"],
        liveLink: "https://heal-hub-navigator.lovable.app/",

    },
    {
        title: "Hotel Website",
        description: "Developed a responsive and visually appealing hotel website using HTML and CSS, emphasizing clean design and functionality.",
        image: "https://res.cloudinary.com/dgtfoqrjo/image/upload/v1740502266/Screenshot_2025-02-25_222054_zvqrhp.png",
        tags: ["CSS", "HTML"],
        liveLink: "https://hotelfoood.niat.tech/",

    }
];

// Generate project cards
function generateProjects() {
    const projectsGrid = document.querySelector('.projects-grid');

    if (!projectsGrid) return;

    projects.forEach((project, index) => {
        // Create project card
        const projectCard = document.createElement('div');
        projectCard.className = 'project-card';

        // Project image
        const projectImage = document.createElement('img');
        projectImage.className = 'project-image';
        projectImage.src = project.image;
        projectImage.alt = project.title;

        // Project overlay
        const projectOverlay = document.createElement('div');
        projectOverlay.className = 'project-overlay';

        // Project content
        const projectContent = document.createElement('div');
        projectContent.className = 'project-content';

        // Project title
        const projectTitle = document.createElement('h3');
        projectTitle.className = 'project-title';
        projectTitle.textContent = project.title;

        // Project description
        const projectDescription = document.createElement('p');
        projectDescription.className = 'project-description';
        projectDescription.textContent = project.description;

        // Project tags
        const projectTags = document.createElement('div');
        projectTags.className = 'project-tags';

        project.tags.forEach(tag => {
            const projectTag = document.createElement('span');
            projectTag.className = 'project-tag';
            projectTag.textContent = tag;
            projectTags.appendChild(projectTag);
        });

        // Project links
        const projectLinks = document.createElement('div');
        projectLinks.className = 'project-links';

        const viewLink = document.createElement('a');
        viewLink.className = 'project-link view-link';
        viewLink.href = project.liveLink;
        viewLink.textContent = 'View Project';
        viewLink.target = '_blank';
        projectLinks.appendChild(viewLink);

        // Assemble project content
        projectContent.appendChild(projectTitle);
        projectContent.appendChild(projectDescription);
        projectContent.appendChild(projectTags);
        projectContent.appendChild(projectLinks);

        // Assemble project card
        projectCard.appendChild(projectImage);
        projectCard.appendChild(projectOverlay);
        projectCard.appendChild(projectContent);

        // Add to DOM
        projectsGrid.appendChild(projectCard);

        // Set animation delay for entrance
        setTimeout(() => {
            projectCard.classList.add('animated');
        }, 200 * index);
    });
}

// Add to your existing DOMContentLoaded event
document.addEventListener('DOMContentLoaded', () => {
    // Your existing code
    // ...

    // Generate projects
    generateProjects();
});
// Initialize GSAP ScrollTrigger
gsap.registerPlugin(ScrollTrigger);

// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize animations
    initExperienceAnimations();
    initParticleBackground();
});

function initExperienceAnimations() {
    // Animate the timeline cards
    const experienceCards = document.querySelectorAll('.experience-card');

    experienceCards.forEach((card, index) => {
        // Create staggered animation for cards
        gsap.to(card, {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: {
                trigger: card,
                start: "top 80%",
                toggleClass: "animate"
            },
            delay: index * 0.2
        });

        // Add hover effect for 3D rotation
        card.addEventListener('mouseenter', function() {
            gsap.to(this.querySelector('.card-inner'), {
                rotateY: 180,
                duration: 1,
                ease: "back.out(1.7)"
            });
        });

        card.addEventListener('mouseleave', function() {
            gsap.to(this.querySelector('.card-inner'), {
                rotateY: 0,
                duration: 1,
                ease: "back.out(1.7)"
            });
        });
    });

    // Animate the skills cube
    const cube = document.querySelector('.skill-cube');

    gsap.from(cube, {
        opacity: 0,
        scale: 0,
        rotateX: 360,
        rotateY: 360,
        duration: 1.5,
        ease: "elastic.out(1, 0.5)",
        scrollTrigger: {
            trigger: '.experience-skills',
            start: "top 80%"
        }
    });

    // Add floating animation to section title
    gsap.to('.section-title', {
        y: 15,
        duration: 2,
        ease: "sine.inOut",
        repeat: -1,
        yoyo: true
    });

    // Create timeline animation
    gsap.from('.experience-timeline::before', {
        height: 0,
        duration: 2,
        ease: "power3.inOut",
        scrollTrigger: {
            trigger: '.experience-timeline',
            start: "top 70%",
            end: "bottom 20%",
            scrub: 1
        }
    });
}

function initParticleBackground() {
    // Create a scene
    const scene = new THREE.Scene();

    // Create a camera
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 5;

    // Create a renderer and attach it to the DOM
    const renderer = new THREE.WebGLRenderer({
        alpha: true
    });
    renderer.setClearColor(0x000000, 0); // transparent background
    renderer.setSize(window.innerWidth, window.innerHeight);

    // Add canvas to experience section as background
    const experienceSection = document.querySelector('.experience-section');
    const canvas = renderer.domElement;
    canvas.style.position = 'absolute';
    canvas.style.top = '0';
    canvas.style.left = '0';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.pointerEvents = 'none';
    canvas.style.zIndex = '0';
    experienceSection.insertBefore(canvas, experienceSection.firstChild);

    // Create particles
    const particlesCount = window.innerWidth > 768 ? 200 : 100;
    const particles = new THREE.BufferGeometry();
    const positions = new Float32Array(particlesCount * 3);
    const colors = new Float32Array(particlesCount * 3);

    const primaryColorRGB = hexToRgb('#6c63ff');
    const secondaryColorRGB = hexToRgb('#4c46b6');

    for (let i = 0; i < particlesCount; i++) {
        // Position
        positions[i * 3] = (Math.random() - 0.5) * 10;
        positions[i * 3 + 1] = (Math.random() - 0.5) * 10;
        positions[i * 3 + 2] = (Math.random() - 0.5) * 10;

        // Color
        const useSecondary = Math.random() > 0.7;
        const color = useSecondary ? secondaryColorRGB : primaryColorRGB;
        colors[i * 3] = color.r / 255;
        colors[i * 3 + 1] = color.g / 255;
        colors[i * 3 + 2] = color.b / 255;
    }

    particles.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    particles.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    // Create particle material
    const particleMaterial = new THREE.PointsMaterial({
        size: 0.05,
        vertexColors: true,
        transparent: true,
        opacity: 0.8
    });

    // Create particle system
    const particleSystem = new THREE.Points(particles, particleMaterial);
    scene.add(particleSystem);

    // Animation function
    const animate = () => {
        requestAnimationFrame(animate);

        // Rotate particle system
        particleSystem.rotation.x += 0.0005;
        particleSystem.rotation.y += 0.0005;

        // Respond to scroll
        const scrollY = window.scrollY || window.pageYOffset;
        const scrollFactor = scrollY / 1000;

        particleSystem.rotation.z = scrollFactor * 0.2;
        particleSystem.position.z = -3 + Math.sin(scrollFactor) * 0.5;

        renderer.render(scene, camera);
    };

    // Handle window resize
    window.addEventListener('resize', () => {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(window.innerWidth, window.innerHeight);
    });

    // Start animation
    animate();
}

// Helper function to convert hex color to RGB
function hexToRgb(hex) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

// Touch device detection and adjustments
function checkTouchDevice() {
    const isTouchDevice = 'ontouchstart' in window || navigator.maxTouchPoints > 0;

    if (isTouchDevice) {
        // For touch devices, make cards flip on tap
        const cards = document.querySelectorAll('.card-inner');

        cards.forEach(card => {
            card.addEventListener('touchstart', function() {
                this.classList.toggle('touch-flip');
            });
        });

        // Add the required CSS
        const style = document.createElement('style');
        style.textContent = `
      .touch-flip {
        transform: rotateY(180deg);
      }
    `;
        document.head.appendChild(style);
    }
}

// Call touch device check after DOM is loaded
document.addEventListener('DOMContentLoaded', checkTouchDevice);

// Smooth scroll to anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});